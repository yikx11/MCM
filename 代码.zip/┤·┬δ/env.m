function n=env(N,t,t0,tmax,tmin,ph,ph0,phmax,phmin,m,m0,mmax,mmin)%֮�������Ϊn������
    if t>t0
        dT=(t-t0)/(tmax-t0);
    else 
        dT=(t-t0)/(tmin-t0);
    end
    if ph>ph0
        dPh=(ph-ph0)/(phmax-ph0);
    else
        dPh=(ph-ph0)/(phmin-ph0);
    end
    if m>m0
        dM=(m-m0)/(mmax-m0);
    else
        dM=(m-m0)/(mmin-m0);
    end
    n=N*(1-dT)^(1/3)*(1-dPh)^(1/3)*(1-dM)^(1/3);