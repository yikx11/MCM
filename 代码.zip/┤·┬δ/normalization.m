clc,clear
water_niche_width=load('wnw.txt');
maxWater=max(water_niche_width);
minWater=min(water_niche_width);
to1wnw=zeros(37);
for i=1:37
    to1wnw(i)=(water_niche_width(i)-minWater)/(maxWater-minWater);
end
xlswrite('to1wnw.xls',to1wnw);