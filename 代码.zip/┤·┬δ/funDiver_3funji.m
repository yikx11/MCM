function dx=fun(t,x,r1,r2,r3,n1,n2,n3,s12,s13,s21,s23,s31,s32)
    ranking=load('ranking.txt');
    rate05=load('rate05.txt');
    NSX=load('NSX.txt');
    Tmax=load('Tmax.txt');
    Tmin=load('Tmin.txt');
    T0=load('T0.txt');
    Mmax=load('Mmax.txt');
    Mmin=load('Mmin.txt');
    M0=load('M0.txt');
    PHmax=load('PHmax.txt');
    PHmin=load('PHmin.txt');
    PH0=load('PH0.txt');
    r1=rate05(8);
    r2=rate05(9);
    r3=rate05(37);
    n1=300;
    n2=300;
    n3=300;
    s12=ranking(8)/ranking(9);
    s13=ranking(8)/ranking(37);
    s21=ranking(9)/ranking(8);
    s23=ranking(9)/ranking(37);
    s31=ranking(37)/ranking(8);
    s32=ranking(37)/ranking(9);
    dx=[r1*x(1)*(1-x(1)/n1-s21*x(2)/n2-s31*x(3)/n3);r2*x(2)*(1-x(2)/n2-s12*x(1)/n1-s32*x(3)/n3);r3*x(3)*(1-x(3)/n3-s13*x(1)/n1-s23*x(2)/n2)];
    
    
    
    
    
    