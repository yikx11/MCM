clc,clear
to1wnw=load('to1wnw.txt');
ranking=load('ranking.txt');
MoistureTolerance=zeros(37);
for i=1:37
    MoistureTolerance(i)=ranking(i)-to1wnw(i);
end
xlswrite('mt.xls',MoistureTolerance);